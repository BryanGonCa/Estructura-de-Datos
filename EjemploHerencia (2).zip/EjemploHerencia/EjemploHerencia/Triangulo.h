#pragma once
#include "Shape.h"
class Triangulo: public Shape {
public:
	Triangulo(void);
	~Triangulo(void);
	int getArea(){
		return ((base*height)/2);
	}

};

