#pragma once
// Base class
class Shape {
protected:
      int width;
      int height;
	  int base;
public:
      void setWidth(int w);
      void setHeight(int h);
	  void setBase(int b);
};

